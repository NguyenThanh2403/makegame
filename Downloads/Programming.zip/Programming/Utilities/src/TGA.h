#pragma once

char * LoadTGA( const char * szFileName, int * width, int * height, int * bpp );
